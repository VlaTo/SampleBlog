using SampleBlog.Web.Identity.Controllers;

var builder = WebApplication.CreateBuilder(args);

builder.Configuration
    .AddEnvironmentVariables()
    .AddJsonFile("appsettings.json")
    .AddJsonFile($"appsettings.{builder.Environment}.json", optional: true)
    .AddUserSecrets<AuthenticationController>()
    ;

// Add services to the container.
builder.Services.AddControllers(options =>
{
    options.RespectBrowserAcceptHeader = true;
});

builder.Services.AddRazorPages();

builder.Services.AddMvc(options =>
{
    //options.
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}

app
    .UseStaticFiles()
    .UseRouting()
    .UseAuthorization();

app.MapRazorPages();

await app.RunAsync();
