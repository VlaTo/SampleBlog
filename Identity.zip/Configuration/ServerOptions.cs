﻿using System.ComponentModel;
using System.Runtime.Serialization;

namespace SampleBlog.Web.Identity.Configuration;


[Serializable, DataContract]
public sealed class ServerOptions
{
    [DataMember(Name = nameof(Secret))]
    public string Secret
    {
        get;
        set;
    }
}