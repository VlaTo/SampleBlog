﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SampleBlog.Core.Application.Features.Commands.Login;
using SampleBlog.Web.Identity.ViewModels;

namespace SampleBlog.Web.Identity.Controllers
{
    //[AllowAnonymous]
    [Route("[controller]")]
    public class AuthenticationController : Controller
    {
        private readonly IMediator mediator;

        public AuthenticationController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet("login")]
        public IActionResult SignIn()
        {
            var signIn = new SignInModel();
            return View("SignIn", signIn);
        }

        [Consumes("application/x-www-form-urlencoded")]
        [HttpPost("login")]
        public async Task<IActionResult> SignIn([FromForm] SignInModel signIn)
        {
            if (ModelState.IsValid)
            {
                var command = new SignInCommand(signIn.Email, signIn.Password, signIn.RememberMe);
                var result = await mediator.Send(command, HttpContext.RequestAborted);

                if (result is { Succeeded: true })
                {
                    if (string.IsNullOrEmpty(signIn.RedirectUrl))
                    {
                        return Redirect("~/");
                    }

                    return Redirect(signIn.RedirectUrl);
                }

                ModelState.AddModelError("error_general", "General error");
            }

            return View("SignIn", signIn);
        }

        [HttpGet("reset")]
        public IActionResult ResetPassword()
        {
            var passwordModel = new ResetPasswordModel();
            return View("ResetPassword", passwordModel);
        }
    }
}
